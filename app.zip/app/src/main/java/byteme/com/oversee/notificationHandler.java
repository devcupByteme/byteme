package byteme.com.oversee;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.Cursor;
import android.content.Context;
import android.content.ContentValues;

public class notificationHandler extends SQLiteOpenHelper {

    private static final int dbversion = 1;
    private static final String dbname = "oversee.db";
    private static final String tbl_notification = "notification";
    private static final String col_id  = "id";
    private static final String col_sentdate = "dateSent";
    private static final String col_message = "message";

    public notificationHandler(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            ///db.execSQL("DROP TABLE IF EXISTS " + tbl_login);
            String query = "CREATE TABLE " + tbl_notification + "(" + col_id + " PRIMARY KEY," +
                                                                      col_sentdate + ","+ col_message +
                                                                 ");";
            db.execSQL(query);
        }catch (Exception ex)
        {

        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + tbl_notification);
        onCreate(db);
    }

    public void getAllNotifcation()
    {
        String dbString = "" ;
        SQLiteDatabase db = getWritableDatabase();
        String query = "Select * from "+tbl_notification;
        Cursor c = db.rawQuery(query,null);
        c.moveToFirst();
        while (!c.isAfterLast())
        {
            if (c.getString(c.getColumnIndex("user")) != null) {

            }
        }
    }



}
