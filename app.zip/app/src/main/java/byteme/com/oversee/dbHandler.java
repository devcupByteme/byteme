package byteme.com.oversee;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.Cursor;
import android.content.Context;
import android.content.ContentValues;
import android.widget.Toast;


public class dbHandler extends SQLiteOpenHelper {

    private static final int dbversion = 1;
    private static final String dbname = "oversee.db";
    private static final String tbl_login = "login";
    private static final String coluser = "user";

    public dbHandler(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            ///db.execSQL("DROP TABLE IF EXISTS " + tbl_login);
            String query = "CREATE TABLE " + tbl_login + "(" + coluser + " PRIMARY KEY);";
            db.execSQL(query);
        }catch (Exception ex)
        {

        }

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + tbl_login);
        onCreate(db);
    }

    public void insertUser(user xuser) {
        ContentValues values = new ContentValues();
        values.put(coluser, xuser.getUsername());
        SQLiteDatabase db = getWritableDatabase();
        db.insert(tbl_login, null, values);
        db.close();
    }

    public void removeUser(String uname) {
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("Delete from " + tbl_login + " where " + coluser + " =\"" + uname + "\";");
    }

    public boolean SearchUser(String uname)
    {
        String query = "Select * from "+tbl_login + " Where " + coluser + " =\"" + uname + "\";";
        SQLiteDatabase db = getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        if(cursor.getCount() <= 0){
            cursor.close();
            return false;
        }
        cursor.close();
        return true;
    }

    public boolean UserAlreadyLogin()
    {
        String query = "Select * from "+tbl_login;
        SQLiteDatabase db = getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        if(cursor.getCount() <= 0){
            cursor.close();
            return true;
        }
        cursor.close();
        return false;
    }



}
