package byteme.com.oversee;

import android.app.Notification;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.app.ActionBar;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import java.util.ArrayList;
import java.util.List;

public class dashboard extends  Activity {

    private List<notification> notifications = new ArrayList<notification>();
    notificationHandler notifydb;

    private static final String SOAP_ACTION = "ByteMeWebService/GetMobileNotification";
    private static final String METHOD_NAME = "GetMobileNotification";
    private static final String NAMESPACE = "ByteMeWebService";
    private static final String URL = "http://10.10.14.148/ByteMeWS.asmx";
    //private static final String URL = "http://10.0.2.2/ByteMeWebService.asmx";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        notifydb = new notificationHandler(this,null,null,1);

        //getNotifications();

        String[] messagex = getNotifications();
        ListAdapter messageadapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,messagex);
        ListView messagelistview = (ListView) findViewById(R.id.notificationList);
        messagelistview.setAdapter(messageadapter);

    }

    private String[] getNotifications() {
        String resTxt = null;

        SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);
        request.addProperty("parentId",1);
        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);

        envelope.setOutputSoapObject(request);
        envelope.dotNet = true;

        try {
            HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
            androidHttpTransport.call(SOAP_ACTION, envelope);
            SoapPrimitive response = (SoapPrimitive) envelope.getResponse();
            resTxt = response.toString();
           // Toast.makeText(getApplicationContext(), "resTxt =" + resTxt, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "ERROR:" + e.getStackTrace(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }

        if (resTxt == null) {
           return  null;
        }

        return  resTxt.split("\\|");
    }

}
