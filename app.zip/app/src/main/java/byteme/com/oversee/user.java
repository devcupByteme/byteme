package byteme.com.oversee;

public class user {
    private String username;

    public user() {}

    public user(String xuser)
    {
        this.username = xuser;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
