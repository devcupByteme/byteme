package byteme.com.oversee;

import android.content.DialogInterface;
import android.os.StrictMode;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;


import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;


public class MainActivity extends AppCompatActivity {

    private static final String SOAP_ACTION = "ByteMeWebService/LogIn";
    private static final String METHOD_NAME = "LogIn";
    private static final String NAMESPACE = "ByteMeWebService";
    private static final String URL = "http://10.10.14.148/ByteMeWS.asmx";
    //private static final String URL = "http://10.0.2.2/ByteMeWS.asmx";

    EditText txtUser, txtPword;
    dbHandler mydb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtUser = (EditText) findViewById(R.id.userID);
        txtPword = (EditText) findViewById(R.id.pword);

        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }
        mydb = new dbHandler(this,null,null,1);

         boolean userExist = false;
       // boolean userExist = mydb.UserAlreadyLogin();
        //Toast.makeText(getApplicationContext(),userExist?"TRUE":"FALSE" , Toast.LENGTH_LONG).show();

        if (userExist)
        {
            Intent i = new Intent(this, dashboard.class);
            startActivity(i);
        }
    }

    public void onLogin(View view) {
        if (doLogin()) {
            //LoginUser(txtUser.getText().toString());
            Intent i = new Intent(this, dashboard.class);
            startActivity(i);
        } else {
            MessageBox("Login Problem","Invalid User name/ Password ! ");
        }
    }

    private void LoginUser(String uname)
    {
        user xuser = new user(uname);
        mydb.insertUser(xuser);
    }

    private boolean doLogin() {
        String resTxt = null;

        SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);
        request.addProperty("username", txtUser.getText().toString());
        request.addProperty("password", txtPword.getText().toString());

        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);

        envelope.setOutputSoapObject(request);
        envelope.dotNet = true;

        try {
            HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
            androidHttpTransport.call(SOAP_ACTION, envelope);
            SoapPrimitive response = (SoapPrimitive) envelope.getResponse();
            resTxt = response.toString();
            //Toast.makeText(getApplicationContext(), "resTxt =" + resTxt, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            //Toast.makeText(getApplicationContext(), "ERROR:" + e.getStackTrace(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
        if (resTxt == null) {
            return false;
        }
        return resTxt.trim().equals("true") ? true : false;
    }

    private void MessageBox(String xtitle, String xMessage) {

        new AlertDialog.Builder(this)
                .setTitle(xtitle)
                .setMessage(xMessage)
                .setCancelable(false)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                     //action here
                    }
                })
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }
}
