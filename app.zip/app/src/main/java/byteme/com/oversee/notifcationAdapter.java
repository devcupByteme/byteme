package byteme.com.oversee;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

class notifcationAdapter extends ArrayAdapter<notification>{

    notifcationAdapter(Context context, notification[] notify)
    {
        super(context,R.layout.customrow,notify);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater myinflater = LayoutInflater.from(getContext());
        View customView = myinflater.inflate(R.layout.customrow,parent,false);

        //String eachRow = getItem(position);

        return super.getView(position, convertView, parent);
    }
}
