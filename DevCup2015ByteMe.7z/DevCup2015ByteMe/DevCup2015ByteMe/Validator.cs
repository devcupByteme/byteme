﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DevCup2015ByteMe
{
    public static class Validator
    {
        public static bool IsMobileNumberValid(string mobileNo)
        {
            string msg = "Mobile number invalid";
            if(!mobileNo.StartsWith("639"))
            {
                throw new Exception(msg);
            }
            else
            {
                if(mobileNo.Length != 12)
                {
                    throw new Exception(msg);
                }
                else
                {
                    Int64 resultMobileNo = 0;
                    if (!Int64.TryParse(mobileNo, out resultMobileNo))
                    {
                        throw new Exception(msg);
                    }
                }
            }
            return true;
        }

        public static bool IsSMSValid(string sms)
        {
            if(sms.Length == 0)
            {
                throw new Exception("Invalid SMS Value");
            }
            return true;
        }
    }
}