﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using MySql.Data.MySqlClient;

namespace DevCup2015ByteMe
{
    public class SQLMaid : IDisposable
    {
        private static string conString = ConfigurationManager.ConnectionStrings["ByteMeConnString"].ConnectionString;

        public KeyValuePair<String, object>[] Parameter;

        public CommandType CommandTypeText = CommandType.Text;
        public CommandType CommandTypeStoredProc = CommandType.StoredProcedure;

        private MySqlConnection myConnection;
        private MySqlCommand myCommand;
        private MySqlDataAdapter myDAdapter;
        private MySqlDataReader myDReader;
        private MySqlTransaction myTransaction;

        public SQLMaid()
        {
            SetConnection();
        }

        [MTAThread]
        void SetConnection()
        {
            myConnection = new MySqlConnection();
            myConnection.ConnectionString = conString;
        }

        [MTAThread]
        bool OpenConnection()
        {
            try
            {
                if (myConnection.State != ConnectionState.Open)
                {
                    myConnection.Open();
                }
            }
            catch(Exception e)
            {
                return false;
            }
            return true;
        }

        [MTAThread]
        bool CloseConnection()
        {
            try
            {
                if (myConnection.State == ConnectionState.Open)
                {
                    myConnection.Close();
                }
            }
            catch (Exception e)
            {
                return false;
            }
            return true;
        }

        [MTAThread]
        MySqlCommand SetCommand(string cmdText, CommandType cmdType)
        {
            try
            {
                myCommand = myConnection.CreateCommand();

                myCommand.CommandType = cmdType;
                myCommand.CommandText = cmdText;

                return myCommand;
            }
            catch(Exception e)
            {
                throw e;
            }
        }

        [MTAThread]
        public MySqlDataAdapter SetDataAdapter(MySqlCommand sqlCommand)
        {
            try
            {
                myDAdapter = new MySqlDataAdapter(sqlCommand);

                return myDAdapter;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [MTAThread]
        public void SetParameter(MySqlCommand sqlCommand, KeyValuePair<String, object>[] parameters)
        {
            try
            {
                if (parameters == null) return;

                foreach (KeyValuePair<String, object> p in parameters)
                {
                    MySqlParameter dbParam = sqlCommand.CreateParameter();

                    dbParam.ParameterName = p.Key;
                    dbParam.Value = p.Value;
                    //dbParam.DbType = GetType(p.Value.GetType());

                    sqlCommand.Parameters.Add(dbParam);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [MTAThread]
        public bool ExecuteNonQuery(string cmdText, CommandType cmdType, KeyValuePair<string, object>[] Parameters = null)
        {
            try
            {
                if (OpenConnection())
                {
                    try
                    {
                        myCommand = SetCommand(cmdText, cmdType);
                        SetParameter(myCommand, Parameters);

                        myTransaction = myConnection.BeginTransaction();

                        myCommand.Connection = myConnection;
                        myCommand.Transaction = myTransaction;

                        myCommand.ExecuteNonQuery();

                        myTransaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        try
                        {
                            myTransaction.Rollback();
                            return false;
                        }
                        catch (Exception exRollBack)
                        {
                            throw exRollBack;
                        }
                    }
                    finally
                    {
                        CloseConnection();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return true;
        }

        [MTAThread]
        public object ExecuteScalar(string cmdText, CommandType cmdType, KeyValuePair<string, object>[] Parameters = null)
        {
            var returnValue = new object();
            try
            {
                if (OpenConnection())
                {
                    try
                    {
                        myCommand = SetCommand(cmdText, cmdType);
                        SetParameter(myCommand, Parameters);

                        returnValue = myCommand.ExecuteScalar();
                    }
                    catch (Exception ex)
                    {
                        CloseConnection();
                        throw ex;
                    }
                    finally
                    {
                        CloseConnection();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return returnValue;
        }

        [MTAThread]
        public DataTable GetDataTable(string cmdText, CommandType cmdType, KeyValuePair<string, object>[] Parameters = null)
        {
            DataTable dt = new DataTable();
            try
            {
                if (OpenConnection())
                {
                    try
                    {
                        myCommand = SetCommand(cmdText, cmdType);
                        SetParameter(myCommand, Parameters);

                        myDAdapter = SetDataAdapter(myCommand);
                        myDAdapter.SelectCommand = myCommand;

                        myDAdapter.Fill(dt);
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    finally
                    {
                        CloseConnection();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dt;
        }

        public void Dispose()
        {
        }
    }
}