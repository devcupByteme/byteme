﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Services;
using Microsoft.SqlServer.Server;

namespace DevCup2015ByteMe
{
    /// <summary>
    /// Summary description for ByteMeWS
    /// </summary>
    [WebService(Namespace = "ByteMeWebService")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class ByteMeWS : System.Web.Services.WebService
    {
        //SMS ------------------------------------------------------------------
        [WebMethod]
        public bool CreateNotification(int userId, int broadcast = 0, int sentStudentId = 0, string message = null)
        {
            bool resultNotif = false;
            try
            {
                if (broadcast == 1)
                {
                    DataTable dtRecipients = GetListRecipients();

                    string mobileNo = string.Empty;
                    foreach (DataRow d in dtRecipients.Rows)
                    {
                        mobileNo = d[0].ToString();

                        int studentId = GetStudentIdMobileNo(mobileNo);
                        using (SQLMaid s = new SQLMaid())
                        {
                            Array.Resize(ref s.Parameter, 6);

                            s.Parameter[0] = new KeyValuePair<string, object>("@pCreatedBy", userId);
                            s.Parameter[1] = new KeyValuePair<string, object>("@pBroadCast", broadcast);
                            s.Parameter[2] = new KeyValuePair<string, object>("@pSent_StudentId", studentId);
                            s.Parameter[4] = new KeyValuePair<string, object>("@pStatus", 0);
                            s.Parameter[5] = new KeyValuePair<string, object>("@pMsg", message);

                            resultNotif = s.ExecuteNonQuery("spNotification", s.CommandTypeStoredProc, s.Parameter);
                        }
                        
                        SendNotification(mobileNo, message);
                    }

                    //SendSchoolAnnouncement(message);

                    

                    if (!resultNotif) return false;
                }
                else
                {
                    if (sentStudentId != 0)
                    {
                        using (SQLMaid s = new SQLMaid())
                        {
                            Array.Resize(ref s.Parameter, 6);

                            s.Parameter[0] = new KeyValuePair<string, object>("@pCreatedBy", userId);
                            s.Parameter[1] = new KeyValuePair<string, object>("@pBroadCast", broadcast);
                            s.Parameter[2] = new KeyValuePair<string, object>("@pSent_StudentId", sentStudentId);
                            s.Parameter[4] = new KeyValuePair<string, object>("@pStatus", 0);
                            s.Parameter[5] = new KeyValuePair<string, object>("@pMsg", message);

                            resultNotif = s.ExecuteNonQuery("spNotification", s.CommandTypeStoredProc, s.Parameter);
                        }

                        string mobileNoStudent = GetMobileNumberStudent(sentStudentId);
                        string mobileNoParent = GetMobileNumberParent(sentStudentId);

                        SendNotification(mobileNoStudent, message);
                        SendNotification(mobileNoParent, message);

                    }
                }
            }
            catch (Exception e)
            {
                throw;
                return false;
            }
            return true;
        }

        private int GetStudentIdMobileNo(string mobileNo)
        {
            int studentId = 0;

            using(SQLMaid s = new SQLMaid())
            {
                Array.Resize(ref s.Parameter, 1);

                s.Parameter[0] = new KeyValuePair<string, object>("@pStudentMobileNo" , mobileNo);

                studentId=Convert.ToInt32(s.ExecuteScalar("spGetStudentIdByMobileNo", s.CommandTypeStoredProc, s.Parameter));
            }

            return studentId;
        }

        private int GetStudentParentId(int sentStudentId)
        {
            int parentId = 0;

            using(SQLMaid s = new SQLMaid())
            {
                Array.Resize(ref s.Parameter, 1);

                s.Parameter[0] = new KeyValuePair<string, object>("@pStudentId", sentStudentId);

                s.ExecuteScalar("getStudentParentId", s.CommandTypeStoredProc, s.Parameter);
            }

            return parentId;
        }

        [WebMethod]
        public bool AbsentAttendance(int studentId)
        {
            bool queryResult = false;
            try
            {
                using(SQLMaid s = new SQLMaid())
                {
                    Array.Resize(ref s.Parameter, 1);

                    s.Parameter[0] = new KeyValuePair<string, object>("@pStudentId", studentId);

                    queryResult=s.ExecuteNonQuery("spAttendance", s.CommandTypeStoredProc, s.Parameter);
                }
            }
            catch(Exception e)
            {
                throw e;
            }
            if(queryResult)
            {
                queryResult = AbsentNotification(studentId);
            }

            return queryResult;
        }

        DataTable GetStudentDetails(int studentId)
        {
            try
            {
                using(SQLMaid s = new SQLMaid())
                {
                    Array.Resize(ref s.Parameter, 1);

                    s.Parameter[0] = new KeyValuePair<string, object>("@pStudentId", studentId);

                    return s.GetDataTable("detailsStudent", s.CommandTypeStoredProc, s.Parameter);
                }
            }
            catch(Exception e)
            {
                throw e;
            }
        }

        [WebMethod]
        public string GetMobileNumberStudent(int studentId)
        {
            string mobileNo = string.Empty;
            using (SQLMaid s = new SQLMaid())
            {
                Array.Resize(ref s.Parameter, 1);

                s.Parameter[0] = new KeyValuePair<string, object>("@pStudentId", studentId);

                mobileNo = Convert.ToString(s.ExecuteScalar("getMobileNoStudent", s.CommandTypeStoredProc, s.Parameter));
            }
            return mobileNo;
        }

        [WebMethod]
        public string GetMobileNumberParent(int studentId)
        {
            string mobileNo = string.Empty;
            using (SQLMaid s = new SQLMaid())
            {
                Array.Resize(ref s.Parameter, 1);

                s.Parameter[0] = new KeyValuePair<string, object>("@pStudentId", studentId);

                mobileNo = Convert.ToString(s.ExecuteScalar("getMobileNoParent", s.CommandTypeStoredProc, s.Parameter));
            }
            return mobileNo;
        }

        [WebMethod]
        public string SendNotification(string mobileNumber, string message)
        {
            string returnNotification = string.Empty;

            try
            {
                if(mobileNumber.StartsWith("0"))
                {
                    mobileNumber = "63" + mobileNumber.Substring(1);
                }

                if (Validator.IsMobileNumberValid(mobileNumber)) ;

                if (Validator.IsSMSValid(message)) ;

                string messageId = ByteMeTools.GenerateMessageId();

                string url = @"https://post.chikka.com/smsapi/request";
                using (WebClient wc = new WebClient())
                {

                    byte[] response = wc.UploadValues(url, new NameValueCollection()
                    {
                        {"message_type", "SEND"},
                        {"mobile_number", mobileNumber},
                        {"shortcode", "29290290640"},
                        {"message_id", messageId},
                        {"message", message},
                        {"client_id", "691eef1fba03f04228c11f109986f7ad3f675e2775439081dce37eb175665bfe"},
                        {"secret_key", "077985927a1a9b5a3f463c38c6cb5d99437032f8bf3804c2ceb92b7608b7138e"}
                    });

                    returnNotification = System.Text.Encoding.UTF8.GetString(response);
                }
            }
            catch (Exception e)
            {
                returnNotification = e.Message;
            }
            return returnNotification;
        }
        
        public bool AbsentNotification(int studentId)
        {
            try
            {
                string msgNotif = "Mr./Ms. {0}, student {1} is absent this day.";

                DataTable dt = GetStudentDetails(studentId);

                string mobileNoStudent = string.Empty;
                string mobileNoParent= string.Empty;
                string nameStudent= string.Empty;
                string nameParent = string.Empty;

                nameStudent = dt.Rows[0]["name"].ToString();
                nameParent = dt.Rows[0]["parentname"].ToString();
                mobileNoStudent = dt.Rows[0]["mobileno"].ToString();
                mobileNoParent = dt.Rows[0]["parentmobileno"].ToString();

                msgNotif = string.Format(msgNotif, nameParent, nameStudent);

                SendNotification(mobileNoParent, msgNotif);
                SendNotification(mobileNoStudent, msgNotif);
            }
            catch (Exception e)
            {
                throw e;
            }
            return true;
        }

        [WebMethod]
        public void SendSchoolAnnouncement(string message)
        {
            try
            {
                DataTable dtRecipients = GetListRecipients();

                string mobileNo = string.Empty;
                foreach (DataRow d in dtRecipients.Rows)
                {
                    mobileNo = d[0].ToString();
                    SendNotification(mobileNo, message);
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        [WebMethod]
        public string GetMobileNotification(int parentId)
        {
           DSet.DTNotificationDataTable dt = new DSet.DTNotificationDataTable();
            try
            {
                using (SQLMaid s = new SQLMaid())
                {
                    Array.Resize(ref s.Parameter, 1);

                    s.Parameter[0] = new KeyValuePair<string, object>("@pParentId", parentId);

                    dt.Merge(s.GetDataTable("getMobileNotification", s.CommandTypeStoredProc,s.Parameter));
                }
            }
            catch (Exception e)
            {
                throw e;
            }

            var dtString = (from t in dt.AsEnumerable()
                select new
                {
                   id =t.id.ToString(),
                   t.msg,
                   datecreated=t.datecreated.ToString("yyyy-MM-dd")
                }).ToList().ConvertListToDataTable();

            StringBuilder sb = new StringBuilder();

            foreach(DataRow d in dtString.Rows)
            {
                sb.Append(string.Format("{0},{1},{2}|", d["id"].ToString(), d["msg"].ToString(), d["datecreated"].ToString()));
            }

            return sb.ToString();
        }

        [WebMethod]
        public bool RegisterStudent(string name, 
                                    string mobileno, 
                                    string parentname,
                                    string parentmobileno,
                                    int classid)
        {
            try
            {
                using (SQLMaid s = new SQLMaid())
                {
                    Array.Resize(ref s.Parameter, 5);

                    s.Parameter[0] = new KeyValuePair<string, object>("@pName", name);
                    s.Parameter[1] = new KeyValuePair<string, object>("@pMobileNo", mobileno);
                    s.Parameter[2] = new KeyValuePair<string, object>("@pParentName", parentname);
                    s.Parameter[3] = new KeyValuePair<string, object>("@pParentMobileNo", parentmobileno);
                    s.Parameter[4] = new KeyValuePair<string, object>("@pClassId", classid);

                    s.ExecuteNonQuery("spStudent", CommandType.StoredProcedure, s.Parameter);
                }
            }
            catch (Exception e)
            {
                throw e;
                return false;
            }
            return true;
        }

        [WebMethod]
        public bool RegisterParent(string name, string mobileno, int studentid)
        {
            try
            {
                using (SQLMaid s = new SQLMaid())
                {
                    Array.Resize(ref s.Parameter, 3);

                    s.Parameter[0] = new KeyValuePair<string, object>("@pName", name);
                    s.Parameter[1] = new KeyValuePair<string, object>("@pMobileNo", mobileno);
                    s.Parameter[2] = new KeyValuePair<string, object>("@pStudentId", studentid);

                    s.ExecuteNonQuery("spParent", CommandType.StoredProcedure, s.Parameter);
                }
            }
            catch (Exception e)
            {
                throw e;
                return false;
            }
            return true;
        }

        [WebMethod]
        public bool RegisterSchool(string name,
                                    string address,
                                    string telno,
                                    string mobileno,
                                    string contactperson,
                                    string position)
        {
            try
            {
                using (SQLMaid s = new SQLMaid())
                {
                    Array.Resize(ref s.Parameter, 6);

                    s.Parameter[0] = new KeyValuePair<string, object>("@pName", name);
                    s.Parameter[1] = new KeyValuePair<string, object>("@pAddress", address);
                    s.Parameter[2] = new KeyValuePair<string, object>("@pTelNo", telno);
                    s.Parameter[3] = new KeyValuePair<string, object>("@pMobileNo", mobileno);
                    s.Parameter[4] = new KeyValuePair<string, object>("@pContactPerson", contactperson);
                    s.Parameter[5] = new KeyValuePair<string, object>("@pPosition", position);

                    s.ExecuteNonQuery("spSchool", CommandType.StoredProcedure, s.Parameter);
                }
            }
            catch (Exception e)
            {
                throw e;
                return false;
            }
            return true;
        }

        [WebMethod]
        public bool RegisterTeacher(string username,
                                    string password,
                                    string name,
                                    string mobileno)
        {

            try
            {
                using (SQLMaid s = new SQLMaid())
                {
                    Array.Resize(ref s.Parameter, 4);

                    s.Parameter[0] = new KeyValuePair<string, object>("@pUserName", username);
                    s.Parameter[1] = new KeyValuePair<string, object>("@pPassword", password);
                    s.Parameter[2] = new KeyValuePair<string, object>("@pName", name);
                    s.Parameter[3] = new KeyValuePair<string, object>("@pMobileNo", mobileno);

                    s.ExecuteNonQuery("spTeacher", CommandType.StoredProcedure, s.Parameter);
                }
            }
            catch (Exception e)
            {
                throw e;
                return false;
            }
            return true;
        }

        DataTable GetListRecipients()
        {
            using (SQLMaid s = new SQLMaid())
            {
                return s.GetDataTable("listRecipients", CommandType.StoredProcedure);
            }
        }

        [WebMethod]
        public bool LogIn(string username, string password)
        {
            bool isValidLogIn = false;
            using (SQLMaid s = new SQLMaid())
            {
                Array.Resize(ref s.Parameter, 2);

                s.Parameter[0] = new KeyValuePair<string, object>("@pUsername", username);
                s.Parameter[1] = new KeyValuePair<string, object>("@pPassword", password);

                isValidLogIn = Convert.ToBoolean(s.ExecuteScalar("spLogIn", s.CommandTypeStoredProc, s.Parameter));
            }
            return isValidLogIn;
        }

        //Look Up --------------------------------------------------------------------------
        [WebMethod]
        public DataTable LookUpStudent()
        {
            DSet.DTStudentDataTable dt = new DSet.DTStudentDataTable();
            using (SQLMaid s = new SQLMaid())
            {
                dt.Merge(s.GetDataTable("lookupStudent", s.CommandTypeStoredProc)); 
            }
            return dt;
        }

        [WebMethod]
        public DataTable LookUpTeacher()
        {
            DSet.DTTeacherDataTable dt = new DSet.DTTeacherDataTable();

            using(SQLMaid s = new SQLMaid())
            {
                dt.Merge(s.GetDataTable("lookupadviser", s.CommandTypeStoredProc));
            }

            return dt;
        }

        [WebMethod]
        public DataTable LookUpSchool()
        {
            using (SQLMaid s = new SQLMaid())
            {
                return s.GetDataTable("lookupSchool", s.CommandTypeStoredProc);
            }
        }

        [WebMethod]
        public DataTable LookUpUser()
        {
            using (SQLMaid s = new SQLMaid())
            {
                return s.GetDataTable("lookupUser", s.CommandTypeStoredProc);
            }
        }
    }
}
